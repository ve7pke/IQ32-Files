Loading Instructions

Place the image.bin file in the root of a USB flash drive having a capacity of 4GB or less
With the IQ32 powered off, insert the USB drive
Press and hold down the frequency encoder while powering on the IQ32
The screen will remain white - you can release the encoder and wait for the unit to finish loading (~15 s)
Once the program is loaded the unit will automatically boot into normal operation
Check the new build version and date on the splash screen during boot